require('dotenv').config();
const { Client, GatewayIntentBits } = require('discord.js');
const responses = require('./responses.json');
const OpenAI = require('openai');

const openai = new OpenAI(process.env.OPENAI_API_KEY);

const client = new Client({
    intents: [
      GatewayIntentBits.DirectMessages,
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildBans,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
    ],
});

// ... rest of your code ...

client.login(process.env.DISCORD_BOT_TOKEN);


const CHANNEL_NAME = "➤chat";
const CHANNEL_ID = "1069267297132367954";

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

client.on('messageCreate', async message => {
    if (message.author.bot) return;
    console.log(`Received message from ${message.author.tag}: ${message.content}`);

    // Handle messages regardless of mention
    const lowerCaseMessage = message.content.toLowerCase();
    if (responses[lowerCaseMessage]) {
        message.channel.send(responses[lowerCaseMessage]);
        console.log(`Responded with predefined message to: ${message.content}`);
    }

    // Additional handling for messages that mention the bot
    if (message.mentions.has(client.user)) {
        const content = message.content.split(' ').slice(1).join(' '); // Remove the mention part

        if (content.startsWith('image:')) {
            // Handle image generation request
            const imagePrompt = content.split('image:')[1].trim();
            console.log(`Image generation requested with prompt: ${imagePrompt}`);
            // Image generation logic goes here
        } else {
            // Handle GPT response
            console.log(`GPT prompt received: ${content}`);
            // GPT interaction logic goes here
        }
    }
});


client.login(process.env.DISCORD_BOT_TOKEN);
